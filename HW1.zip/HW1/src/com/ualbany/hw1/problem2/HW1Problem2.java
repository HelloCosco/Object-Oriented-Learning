package com.ualbany.hw1.problem2;

public class HW1Problem2 {
	
	//boolean multiple
	 public boolean multiple(int x, int y)
	   {
		 //remainder is true
	       if(x % y == 0){
	           return true;
	       }
	       //if not false
	       else{
	           return false;
	       }
	   }
	 	//int reminder
	   public int reminder(int x)
	   {
	       return x % 7;
	   }
	   //double distance
	   public double distance(double x1, double y1, double x2, double y2){
		   //math.sqrt
	       return Math.sqrt((x2-x1) * (x2-x1) + (y2 - y1) * (y2 - y1));
	   }
	   //void flips
	   public void flips(){
	       for(int i=0; i<10; i++){
	           System.out.println((int)(Math.random() * 10));
	       }
	   }

}
