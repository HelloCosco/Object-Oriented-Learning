package com.ualbany.hw1.problem2;
import java.util.Scanner;

public class Problem2Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//try scanner scan will stay open and close by itself
		 try(Scanner scan = new Scanner(System.in)){
			 //Hw1Problem2 conjure new HW1Problem
	       HW1Problem2 h =new HW1Problem2();
	       
	       //print first number
	       System.out.print("Enter the first number : ");
	       int a = scan.nextInt();
	       
	       //print second number
	       System.out.print("Enter the second number : ");
	       int b = scan.nextInt();
	       
	       //Divide 
	       System.out.println(a+" number is divisible by "+b+": "+h.multiple(a, b));
	       System.out.print("Enter the number : ");
	       int c = scan.nextInt();
	       
	       //remainder of value divided by 7
	       System.out.println("The remainder of the value "+c+" divided by 7 is "+h.reminder(c));
	       //first coordinates
	       System.out.print("Enter first coordinates : ");
	       double x1 = scan.nextInt();
	       double y1 = scan.nextInt();
	       
	       //second coordinates
	       System.out.print("Enter second coordinates : ");
	       double x2 = scan.nextInt();
	       double y2 = scan.nextInt();
	       
	       //find distance
	       System.out.println("The distance is "+h.distance(x1, y1, x2, y2));
	       
	       //random numbers
	       System.out.println("10 flips of a coin by random number: ");
	       h.flips();
		 }
	}
}
	

