package com.ualbany.hw1.problem3;

public class Bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Declaring instance variables

		String firstname="Johnathan";

		String lastname="Mata";

		  

		System.out.println(firstname+" "+lastname+" arrived to the Bank of America");

		//Creating an instance of CheckingAccount class

		CheckingAccount ca=new CheckingAccount(10000);

		//Creating an instance of Account class

		Address addr=new Address("1400 Washington Ave","Liberty Terrance","Albany","New York","12222");

		//Creating an instance of Person class

		Person p=new Person(firstname, lastname, addr, ca);

		//Performing Deposit

		p.getCa().credit(1000);

		System.out.println("----- Deposit :$1000 -----");

		System.out.println(p);

		//Performing Withdrawn

		p.getCa().debit(500);

		System.out.println("----- Withdrawn :$500 -----");

		System.out.println(p);
	}

}
