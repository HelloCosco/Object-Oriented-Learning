package com.ualbany.hw1.problem3;

public class CheckingAccount {

	//Declaring instance variables

	private double balance;

	//Parameterized constructor

	public CheckingAccount(double balance) 
	{

	super();

	this.balance = balance;

	}

	public void credit(double amt) 
	{

	this.balance += amt;

	}

	public void debit(double amt) 
	{

	this.balance -= amt;

	}

	public double getBalance() 
	{

	return balance;

	}
}
