package com.ualbany.hw1.problem3;

public class Person {

	//Declaring instance variables

	private String firstName;

	private String lastName;

	private Address address;

	private CheckingAccount ca;

	//Parameterized constructor

	public Person(String firstName, String lastName, Address address,

	CheckingAccount ca) {

	super();

	this.firstName = firstName;

	this.lastName = lastName;

	this.address = address;

	this.ca = ca;

	}

	//getters and setters

	public String getFirstName() {

	return firstName;

	}

	public void setFirstName(String firstName) {

	this.firstName = firstName;

	}

	public String getLastName() {

	return lastName;

	}

	public void setLastName(String lastName) {

	this.lastName = lastName;

	}

	public Address getAddress() {

	return address;

	}

	public void setAddress(Address address) {

	this.address = address;

	}

	public CheckingAccount getCa() {

	return ca;

	}

	public void setCa(CheckingAccount ca) {

	this.ca = ca;

	}

	//toString method is used to display the contents of an object inside it

	@Override

	public String toString() {

	return "Person = " + firstName + "," + lastName

	+ ", Address=" + address + ", Balance" + ca.getBalance() ;

	}
}
