package edu.albany.hw2.car;

public class Odometer {
	private int mileage;
    private int setPoint; // Miles since the fuel was last decremented
    private FuelGauge fuelGauge;
   
   
    private final int MAX_MILEAGE = 999999; //mileage
    private final int MPG = 24; //MPG
   
    public Odometer(int m, FuelGauge fg) {
        fuelGauge = fg;
        mileage = m;
   
    }
   
    public int getMileage() {
        return mileage;
    }
   
    public void incrementMileage() {
        mileage += 1;
        // If mileage is over the max, "wrap around"
        mileage = mileage % (MAX_MILEAGE+1);
       
        setPoint += 1; // Keep track of how many miles it's been since we decremented the fuel
        while (setPoint >= MPG) {
            fuelGauge.decrementGallons();
            setPoint = setPoint - MPG;
        }
    }

}
