package edu.albany.hw2.morse;
import java.util.Scanner;
public class Morse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//create a scanner class object
		try(Scanner scanner=new Scanner(System.in)){
		
		System.out.print("Enter english: ");
		
		//prompt user input
		String input=scanner.nextLine();
		
		//print input
		System.out.println("Text: "+input);
		
		//call convertTomorseCodeCode
		String morseCode=convertTomorseCodeCode(input);
		System.out.println("morseCode Code: "+morseCode);
	}
	}
	
	/*
	 * The method convertTomorseCodeCode that takes user input
	 * text argument and then uses a switch to
	 * select morse code and convert text to morse code
	 * */
	
	public static String convertTomorseCodeCode(String text)
	{
		String morseCodeCodeString="";
		String morseCode="";
		
		//run loop that convert text to morse code
		
		for (int index=0; index < text.length(); index++)
		{
			//select the appropriate case label
			switch (text.charAt(index))
			{
			case ' ':
				morseCode="";
				break;
				
			case',':
				morseCode="--..--";
				break;
				
			case'.':
				morseCode=".-.-.-";
				break;
				
			case'?':
				morseCode="..--..";
				break;
				
			case'A':
				morseCode=".-";
				break;
				
			case'a':
				morseCode=".-";
				break;
				
			case'B':
				morseCode="-...";
				break;
				
			case'b':
				morseCode="-...";
				break;
				
			case'C':
				morseCode="-.-.";
				break;
				
			case'c':
				morseCode="-.-.";
				break;
				
			case'D':
				morseCode="-..";
				break;
				
			case'd':
				morseCode="-..";
				break;
				
			case'E':
				morseCode=".";
				break;
				
			case'e':
				morseCode=".";
				break;
				
			case'F':
				morseCode="..-.";
				break;
				
			case'f':
				morseCode="..-.";
				break;
				
			case'G':
				morseCode="--.";
				break;
				
			case'g':
				morseCode="--.";
				break;
				
			case'H':
				morseCode="....";
				break;
				
			case'h':
				morseCode="....";
				break;
				
			case'I':
				morseCode="..";
				break;
				
			case'i':
				morseCode="..";
				break;
				
			case'J':
				morseCode=".---";
				break;
				
			case'j':
				morseCode=".---";
				break;
				
			case'K':
				morseCode="-.-";
				break;
				
			case'k':
				morseCode="-.-";
				break;
				
			case'L':
				morseCode=".-..";
				break;
				
			case'l':
				morseCode=".-..";
				break;
				
			case'M':
				morseCode="--";
				break;
				
			case'm':
				morseCode="--";
				break;
				
			case'N':
				morseCode="-.";
				break;
				
			case'n':
				morseCode="-.";
				break;
				
			case'O':
				morseCode="---";
				break;
				
			case'o':
				morseCode="---";
				break;
				
			case'P':
				morseCode=".--.";
				break;
				
			case'p':
				morseCode=".--.";
				break;
				
			case'Q':
				morseCode="--.-";
				break;
				
			case'q':
				morseCode="--.-";
				break;
				
			case'R':
				morseCode=".-.";
				break;
				
			case'r':
				morseCode=".-.";
				break;
				
			case'S':
				morseCode="...";
				break;
				
			case's':
				morseCode="...";
				break;
				
			case'T':
				morseCode="-";
				break;
				
			case't':
				morseCode="-";
				break;
				
			case'U':
				morseCode="..-";
				break;
				
			case'u':
				morseCode="..-";
				break;
				
			case'V':
				morseCode="...-";
				break;
				
			case'v':
				morseCode="...-";
				break;
				
			case'W':
				morseCode=".--";
				break;
				
			case'w':
				morseCode=".--";
				break;
				
			case'X':
				morseCode="-..-";
				break;
				
			case'x':
				morseCode="-..-";
				break;
				
			case'Y':
				morseCode="-.--";
				break;
				
			case'y':
				morseCode="-.--";
				break;
				
			case'Z':
				morseCode="--..";
				break;
				
			case'z':
				morseCode="--..";
				break;
				
			case'0':
				morseCode="-----";
				break;
				
			case'1':
				morseCode=".----";
				break;
				
			case'2':
				morseCode="..---";
				break;
				
			case'3':
				morseCode="...--";
				break;
				
			case'4':
				morseCode="....-";
				break;
				
			case'5':
				morseCode=".....";
				break;
				
			case'6':
				morseCode="-....";
				break;
				
			case'7':
				morseCode="--...";
				break;
				
			case'8':
				morseCode="---..";
				break;
				
			case'9':
				morseCode="----.";
				break;
			}
			
			//concatenante the morsecode to mroseCodeCodeString
			morseCodeCodeString+=morseCode;
		}
		return morseCodeCodeString;
			
	}

}

