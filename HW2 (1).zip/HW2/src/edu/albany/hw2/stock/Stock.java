package edu.albany.hw2.stock;

public class Stock 
{
	Symbol symbol;

    double previousClosingPrice;

    double currentPrice;

    // creating a Stock

    public Stock(Symbol symbol) 
    {

        this.symbol = symbol;

    }

    // finding percentage change

    public double getChangePercentage() 
    {

        double change = ((currentPrice-previousClosingPrice)/previousClosingPrice);

        return change*100;

    }

    // setter and getters

    public Symbol getSymbol() 
    {

        return symbol;

    }

    public double getPreviousClosingPrice() 
    {

        return previousClosingPrice;

    }

    public double getCurrentPrice() 
    {

        return currentPrice;

    }

    public void setPreviousClosingPrice(double previousClosingPrice) 
    {

        this.previousClosingPrice = previousClosingPrice;

    }

    public void setCurrentPrice(double currentPrice)
    {

        this.currentPrice = currentPrice;

    }

}
