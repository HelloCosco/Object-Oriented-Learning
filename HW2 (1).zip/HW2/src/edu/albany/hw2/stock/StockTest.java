package edu.albany.hw2.stock;

public class StockTest 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		
		 // Microsoft stock

        Stock msft = new Stock(Symbol.MSFT);    // create stock

        msft.setPreviousClosingPrice(58.9); // set previous price

        msft.setCurrentPrice(59);   // set current price

        System.out.println("MSFT stock change: " + msft.getChangePercentage());

        // Amazon stock

        Stock amzn = new Stock(Symbol.AMZN);    // create stock

        amzn.setPreviousClosingPrice(1004.2); // set previous price

        amzn.setCurrentPrice(1000.3);   // set current price

        System.out.println("AMZN stock change: " + amzn.getChangePercentage());

	}

}
