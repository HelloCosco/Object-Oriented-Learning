package edu.albany.hw2.stock;

public enum Symbol 
{
	 // different symbols for stocks

    MSFT ("Microsoft"),

    AAPL ("Apple"),

    AMZN ("Amazon"),

    T ("AT&T");

    private final String name;

    private Symbol(String name)
    {

        this.name = name;

    }

    public String toString() 
    {

        return this.name;

    }

}
