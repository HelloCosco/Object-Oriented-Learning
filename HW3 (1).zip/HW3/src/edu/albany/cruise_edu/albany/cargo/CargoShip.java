package edu.albany.cruise_edu.albany.cargo;

public class CargoShip extends Ship {
	int noOfTonns;

	// constructor for name and year ,number of tonns

	public CargoShip(String name,int year,int noOfTonns)

	{

	super(name,year);

	this.noOfTonns=noOfTonns;

	}

	//return number of tonns

	public int getNoOfTonns()

	{

	return noOfTonns;

	}

	public String toString()

	{

	return "\n Ship name :"+getShipName()+

	"\nShip Capacity :"+getNoOfTonns();

	}

}
