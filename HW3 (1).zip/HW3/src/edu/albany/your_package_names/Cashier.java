package edu.albany.your_package_names;

class Cashier {
	 int costOfSandwich = 10;
	   /**
	    * Function to calculate cost of sandwiches purchased by the customer
	   *
	   * @param int quantity as quantity of sandwiches in the basket
	   *
	   * @return null
	   */
	   public void calculate_cost_of_purchase(int quantity){
	       int totalCostOfSandwich = 0;
	       totalCostOfSandwich = quantity * costOfSandwich;
	       System.out.println("Total quantity of the Sandwich(es) purchased by you = " + quantity);
	       System.out.println("Cost per Sandwich = " + costOfSandwich);
	       System.out.println("Total Cost of Sandwich(es) = " + totalCostOfSandwich);
	   }// end calculate_cost_of_purchase()  
	}// end class Cashier


