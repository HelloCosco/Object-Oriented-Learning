package edu.albany.your_package_names;

import java.util.Scanner;
import java.util.InputMismatchException;
@SuppressWarnings({ "unused", "serial" })
class QuantityException extends Exception {
   String s1;
   QuantityException(String s2) {
      s1 = s2;
   }
   @Override
   /**
    * Function to print the error message
   *
   * @param null
   *
   * @return string message
   */
   public String toString() {
      return (s1);
   }// end toString()
}// end class QuantityException
class Customer {
	   int quantity = 0;
	   int desired_quantity = 0;
	   Scanner cust_sc   =   new Scanner(System.in);
	   /**
	    * Function to add sandwich in the basket
	   *
	   * @param null
	   *
	   * @return null
	   */
	   public void add_sandwich(){
	       System.out.println("How many sandwiches you want to add in your basket ?");
	       desired_quantity = cust_sc.nextInt();
	       try{
	           if(desired_quantity > 0){
	               quantity = quantity + desired_quantity;
	           }else{
	               throw new QuantityException("Please specify a positive numerical value, which is more than 0, for adding the sandwich in your basket.");
	           }
	       }catch(QuantityException e){
	           System.out.println(e);
	       }
	       get_sandwich_quantity();
	   }// end add_sandwich()
	  
	   /**
	    * Function to remove sandwich from the basket
	   *
	   * @param null
	   *
	   * @return null
	   */
	   public void remove_sandwich(){
	       System.out.println("How many sandwiches you want to remove from your basket ?");
	       desired_quantity = cust_sc.nextInt();
	       try{
	           if(desired_quantity > 0 && desired_quantity <= quantity){
	               quantity = quantity - desired_quantity;
	           }else{
	               throw new QuantityException("Please specify either the quantity which is to be removed, less than the current quantity of the sandwiches in the basket or a positive numerical quantity of how much sandwiches have to be removed from your basket.");
	           }
	       }catch(QuantityException e){
	           System.out.println(e);
	       }
	       get_sandwich_quantity();
	   }// end remove_sandwich()
	  
	   /**
	    * Function to purchase sandwiches
	   *
	   * @param int quantity as quantity of sandwich
	   *
	   * @return null
	   */
	   public void purchase_sandwich(int quantity){
	       Cashier cashier_obj = new Cashier();
	       cashier_obj.calculate_cost_of_purchase(quantity);
	   }// end purchase_sandwich()
	  
	   /**
	    * Function to print current quantity of sandwiches in the basket
	   *
	   * @param null
	   *
	   * @return null
	   */
	   public void get_sandwich_quantity(){
	       System.out.println("Quantity in your basket = " + quantity);
	   }// end get_sandwich_quantity()
	}// end class Customer


