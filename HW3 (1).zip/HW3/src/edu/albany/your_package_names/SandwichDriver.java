package edu.albany.your_package_names;

import java.util.Scanner;
import java.util.InputMismatchException;


public class SandwichDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 System.out.println("======   Welcome To Sandwich Shop   ======");
	       Customer cust_obj = new Customer();
	       Scanner sc   =   new Scanner(System.in);
	       while(true){
	           System.out.println("1. Add Sandwich");
	           System.out.println("2. Remove Sandwich");
	           System.out.println("3. Purchase Sandwich");
	           System.out.println("4. Exit the Shop");
	           int choice = 0;
	           System.out.println("Enter your choice");
	           try{
	               choice = sc.nextInt();
	               
	               
	           }catch(InputMismatchException e){
	               System.out.println("Please Enter a valid numerical choice");
	               break;
	           }
	           switch(choice){
	               case 1:
	                   cust_obj.add_sandwich();
	                   break;
	               case 2:
	                   cust_obj.remove_sandwich();
	                   break;
	               case 3:
	                   cust_obj.purchase_sandwich(cust_obj.quantity);
	                   break;
	               case 4:
	                   System.exit(0);
	                   break;
	               default:
	                   System.out.println("Invalid choice, Please Enter again");                                  
	           }
	           
	       }
	       sc.close();
	   }
	
	}// end class SandwichDriver
